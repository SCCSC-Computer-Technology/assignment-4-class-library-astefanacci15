﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatesLibrary_AnnaStefanacci_CPT206
{
    // Anna Stefanacci

    public class States
    {
        private StatesDBDataSet db; // connecting to db
         
        public States()
        {
            db = new StatesDBDataSet();
        }

        // method to search state names
        public IQueryable<States>SearchState(string criteria)
        {
            var results = from state in db.States
                          where state.State_Name.Contains(criteria)
                          select state;
            return (IQueryable<States>)results;
        }

        // method to search state color
        public IQueryable<States>SearchColor(string criteria)
        {
            var results = from state in db.States
                          where state.State_Colors.Contains(criteria)
                          select state;
            return (IQueryable<States>)results;
        }

        // this method would be used to generate more searches for population, capitol, income, etc.

    }
}
